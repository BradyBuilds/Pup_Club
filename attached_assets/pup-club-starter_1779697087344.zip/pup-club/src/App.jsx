import { useEffect, useState } from 'react'
import { useStore } from './store/useStore'
import { getVenue, getGames, getLeaderboardToday, supabase } from './lib/supabase'

import BottomNav       from './components/BottomNav'
import OnboardingModal from './components/OnboardingModal'
import RewardToast     from './components/RewardToast'
import LoadingScreen   from './components/LoadingScreen'

import Hub         from './pages/Hub'
import Leaderboard from './pages/Leaderboard'
import Menu        from './pages/Menu'
import Events      from './pages/Events'
import Profile     from './pages/Profile'

export default function App() {
  const {
    venue, setVenue,
    setGames,
    setLeaderboard,
    hasOnboarded,
    activeTab, setActiveTab,
    pendingRewards,
  } = useStore()

  const [booting, setBooting]   = useState(true)
  const [bootError, setBootError] = useState(null)

  // ── Boot: load venue + games + leaderboard ──────────────
  useEffect(() => {
    async function boot() {
      try {
        const v = await getVenue()
        setVenue(v)

        const [games, lb] = await Promise.all([
          getGames(v.id),
          getLeaderboardToday(v.id),
        ])
        setGames(games)
        setLeaderboard(lb)
      } catch (err) {
        console.error('Boot error:', err)
        setBootError(err.message)
      } finally {
        setBooting(false)
      }
    }
    boot()
  }, [])

  // ── Realtime: subscribe to score updates ────────────────
  useEffect(() => {
    if (!venue) return

    const channel = supabase
      .channel(`scores:${venue.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'scores',
        filter: `venue_id=eq.${venue.id}`,
      }, async () => {
        // Refresh leaderboard on any new score
        const lb = await getLeaderboardToday(venue.id)
        setLeaderboard(lb)
      })
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [venue])

  if (booting) return <LoadingScreen />

  if (bootError) return (
    <div className="flex items-center justify-center h-full bg-bg text-white p-6 text-center">
      <div>
        <div className="text-4xl mb-4">🐾</div>
        <p className="text-pink font-display text-xl mb-2">Connection Error</p>
        <p className="text-white/60 text-sm">{bootError}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-4 px-6 py-2 bg-pink rounded-lg text-white font-display text-lg"
        >
          Retry
        </button>
      </div>
    </div>
  )

  const TABS = { hub: Hub, leaderboard: Leaderboard, menu: Menu, events: Events, profile: Profile }
  const ActivePage = TABS[activeTab] || Hub

  return (
    <div className="flex flex-col h-full bg-bg overflow-hidden">
      {/* Onboarding gate */}
      {!hasOnboarded && <OnboardingModal />}

      {/* Reward toasts */}
      {pendingRewards.map((r) => <RewardToast key={r.id} reward={r} />)}

      {/* Page content */}
      <main className="flex-1 overflow-hidden relative">
        <ActivePage />
      </main>

      {/* Bottom nav — always visible */}
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  )
}
