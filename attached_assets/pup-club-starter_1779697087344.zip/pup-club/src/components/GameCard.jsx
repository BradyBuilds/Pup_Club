import { useStore } from '../store/useStore'

const GAME_META = {
  pong: {
    emoji:    '🏓',
    color:    '#00E5FF',
    gradient: 'from-cyan/20 to-transparent',
    tagline:  'Classic paddle battle',
  },
  'neon-invaders': {
    emoji:    '👾',
    color:    '#FF2D78',
    gradient: 'from-pink/20 to-transparent',
    tagline:  'Tap before they reach you',
  },
  'laser-tug': {
    emoji:    '⚡',
    color:    '#F5E642',
    gradient: 'from-yellow/20 to-transparent',
    tagline:  'Push the laser past your opponent',
  },
}

export default function GameCard({ game, topScore }) {
  const { setActiveTab, setActiveGame } = useStore()
  const meta = GAME_META[game.slug] || { emoji: '🎮', color: '#FF2D78', gradient: 'from-pink/20 to-transparent', tagline: '' }

  function handlePlay() {
    setActiveGame(game)
    setActiveTab('play') // Will route to game screen — to be implemented
    // For now, alert as placeholder
    alert(`🎮 ${game.name}\n\nGame engine coming in Sprint 2!\n\nThe database, leaderboard, and UI are all wired up. Next step: add the Canvas game logic.`)
  }

  return (
    <div
      className={`bg-elevated rounded-2xl overflow-hidden border border-white/10`}
      style={{ boxShadow: `0 0 30px ${meta.color}11` }}
    >
      {/* Top gradient strip */}
      <div className={`h-1 w-full bg-gradient-to-r ${meta.gradient}`}
           style={{ background: `linear-gradient(90deg, ${meta.color}88, transparent)` }} />

      <div className="p-4 flex items-center gap-4">
        {/* Icon */}
        <div className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl flex-shrink-0"
             style={{ background: `${meta.color}22`, border: `1px solid ${meta.color}44` }}>
          {meta.emoji}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <h3 className="font-display text-white text-xl tracking-wide">
            {game.name}
          </h3>
          <p className="text-white/40 text-xs font-body mt-0.5 truncate">
            {meta.tagline}
          </p>

          {/* Current #1 */}
          {topScore ? (
            <div className="mt-2 flex items-center gap-1.5">
              <span className="text-[10px] text-white/30 font-body">TOP:</span>
              <span className="text-xs font-display tracking-wide" style={{ color: meta.color }}>
                {topScore.display_name}
              </span>
              <span className="score-font text-xs text-white/50">
                {topScore.best_score.toLocaleString()}
              </span>
            </div>
          ) : (
            <p className="text-[10px] text-white/20 font-body mt-1">
              No scores yet tonight — be first!
            </p>
          )}
        </div>

        {/* Play button */}
        <button
          onClick={handlePlay}
          className="flex-shrink-0 w-16 h-16 rounded-2xl font-display text-sm
            tracking-wider btn-press transition-transform flex items-center justify-center"
          style={{
            background: `linear-gradient(135deg, ${meta.color}dd, ${meta.color}99)`,
            boxShadow:  `0 0 20px ${meta.color}44`,
          }}
        >
          PLAY
        </button>
      </div>
    </div>
  )
}
