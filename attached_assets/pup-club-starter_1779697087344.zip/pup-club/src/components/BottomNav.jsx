const TABS = [
  { id: 'hub',         icon: '🎮', label: 'Games'  },
  { id: 'leaderboard', icon: '🏆', label: 'Board'  },
  { id: 'menu',        icon: '🍺', label: 'Menu'   },
  { id: 'events',      icon: '🎟️', label: 'Events' },
  { id: 'profile',     icon: '👤', label: 'Me'     },
]

export default function BottomNav({ activeTab, setActiveTab }) {
  return (
    <nav className="flex-shrink-0 bg-surface border-t border-white/10 pb-safe">
      <div className="flex">
        {TABS.map((tab) => {
          const active = activeTab === tab.id
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex-1 flex flex-col items-center justify-center py-3 gap-0.5
                transition-colors duration-100 btn-press
                ${active ? 'text-pink' : 'text-white/40'}
              `}
            >
              <span className="text-xl leading-none">{tab.icon}</span>
              <span className={`text-[10px] font-display tracking-wider uppercase
                ${active ? 'text-pink' : 'text-white/30'}`}>
                {tab.label}
              </span>
              {active && (
                <div className="absolute bottom-0 w-8 h-0.5 bg-pink rounded-full" />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}
