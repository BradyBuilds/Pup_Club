export default function LoadingScreen() {
  return (
    <div className="flex flex-col items-center justify-center h-full bg-bg gap-4">
      <div className="text-6xl animate-bounce">🐾</div>
      <p className="font-display text-2xl tracking-widest text-pink glow-pink">
        PUP CLUB
      </p>
      <p className="text-white/40 text-sm font-body animate-pulse">
        Loading the arena…
      </p>
    </div>
  )
}
