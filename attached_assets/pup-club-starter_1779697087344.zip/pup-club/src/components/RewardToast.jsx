import { useEffect } from 'react'
import { useStore } from '../store/useStore'

export default function RewardToast({ reward }) {
  const { clearReward } = useStore()

  useEffect(() => {
    const timer = setTimeout(() => clearReward(reward.id), 8000)
    return () => clearTimeout(timer)
  }, [reward.id])

  return (
    <div
      className="fixed top-4 left-4 right-4 z-50 bg-elevated border border-neon rounded-2xl
        p-4 flex items-start gap-3 shadow-xl animate-slide-down"
      style={{ boxShadow: '0 0 30px #39FF1444' }}
    >
      <div className="text-3xl">🏆</div>
      <div className="flex-1">
        <p className="font-display text-neon text-lg tracking-wide glow-neon">
          {reward.title}
        </p>
        <p className="text-white/70 text-sm font-body mt-0.5">{reward.description}</p>
        {reward.reward_code && (
          <div className="mt-2 bg-bg rounded-lg px-3 py-1 inline-block">
            <span className="score-font text-yellow tracking-widest text-sm">
              {reward.reward_code}
            </span>
            <span className="text-white/40 text-xs ml-2">— show at bar</span>
          </div>
        )}
      </div>
      <button
        onClick={() => clearReward(reward.id)}
        className="text-white/30 text-lg leading-none mt-0.5"
      >
        ×
      </button>
    </div>
  )
}
