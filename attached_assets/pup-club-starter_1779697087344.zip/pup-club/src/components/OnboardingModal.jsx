import { useState } from 'react'
import { useStore } from '../store/useStore'
import { getOrCreatePatron } from '../lib/supabase'

export default function OnboardingModal() {
  const { venue, sessionToken, setPatron } = useStore()
  const [name,  setName]  = useState('')
  const [email, setEmail] = useState('')
  const [step,  setStep]  = useState(1) // 1 = name, 2 = email optional
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')

  async function handleNameSubmit(e) {
    e.preventDefault()
    if (!name.trim() || name.trim().length < 2) {
      setError('Need at least 2 characters')
      return
    }
    setError('')
    setStep(2)
  }

  async function handleFinish(skipEmail = false) {
    if (loading) return
    setLoading(true)
    try {
      const patron = await getOrCreatePatron({
        venueId:      venue.id,
        sessionToken,
        displayName:  name.trim(),
        email:        skipEmail ? null : (email.trim() || null),
        phone:        null,
      })
      setPatron(patron)
    } catch (err) {
      setError('Something went wrong. Try again.')
      setLoading(false)
    }
  }

  return (
    <div className="absolute inset-0 z-50 bg-bg/95 backdrop-blur flex flex-col items-center justify-center p-6">
      {/* Brand */}
      <div className="text-5xl mb-2">🐾</div>
      <h1 className="font-display text-4xl tracking-widest text-pink glow-pink mb-1">
        PUP CLUB
      </h1>
      <p className="text-white/50 text-sm font-body mb-8 text-center">
        Deaf Puppy Comedy Club · Manteca, CA
      </p>

      {step === 1 ? (
        /* ── Step 1: Name ───────────────────────────────── */
        <form onSubmit={handleNameSubmit} className="w-full max-w-sm flex flex-col gap-4">
          <div>
            <label className="text-white/60 text-xs font-display tracking-wider uppercase mb-2 block">
              Enter Your Name to Play
            </label>
            <input
              autoFocus
              value={name}
              onChange={(e) => { setName(e.target.value); setError('') }}
              placeholder="HotDog_Kyle"
              maxLength={20}
              className="w-full bg-elevated border border-white/20 rounded-xl px-4 py-4
                text-white font-display text-xl tracking-wide placeholder-white/20
                focus:outline-none focus:border-pink transition-colors"
            />
            {error && <p className="text-pink text-xs mt-1">{error}</p>}
          </div>
          <button
            type="submit"
            className="w-full bg-pink rounded-xl py-4 font-display text-xl tracking-widest
              text-white box-glow-pink btn-press"
          >
            ENTER THE ARENA →
          </button>
        </form>
      ) : (
        /* ── Step 2: Email (optional) ───────────────────── */
        <div className="w-full max-w-sm flex flex-col gap-4">
          <div className="bg-elevated rounded-xl p-4 text-center mb-2">
            <p className="text-neon font-display text-lg glow-neon">+50 BONUS XP</p>
            <p className="text-white/50 text-xs mt-1">Save your score + get notified about events</p>
          </div>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com (optional)"
            className="w-full bg-elevated border border-white/20 rounded-xl px-4 py-4
              text-white font-body text-base placeholder-white/20
              focus:outline-none focus:border-cyan transition-colors"
          />
          {error && <p className="text-pink text-xs">{error}</p>}
          <button
            onClick={() => handleFinish(false)}
            disabled={loading}
            className="w-full bg-pink rounded-xl py-4 font-display text-xl tracking-widest
              text-white box-glow-pink btn-press disabled:opacity-50"
          >
            {loading ? 'LOADING…' : 'CLAIM XP + PLAY →'}
          </button>
          <button
            onClick={() => handleFinish(true)}
            disabled={loading}
            className="text-white/30 text-sm font-body text-center py-2 btn-press"
          >
            Skip — just play
          </button>
        </div>
      )}
    </div>
  )
}
