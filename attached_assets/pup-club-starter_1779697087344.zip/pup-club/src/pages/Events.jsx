import { useEffect, useState } from 'react'
import { useStore } from '../store/useStore'
import { getEvents } from '../lib/supabase'

export default function Events() {
  const { venue } = useStore()
  const [events, setEvents]   = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!venue) return
    getEvents(venue.id)
      .then(setEvents)
      .finally(() => setLoading(false))
  }, [venue])

  function formatDate(dateStr) {
    const d = new Date(dateStr + 'T12:00:00')
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
  }

  function isToday(dateStr) {
    return dateStr === new Date().toLocaleDateString('en-CA')
  }

  return (
    <div className="h-full flex flex-col">
      <div className="px-4 pt-5 pb-4 flex-shrink-0">
        <h1 className="font-display text-3xl tracking-widest text-white">EVENTS</h1>
        <p className="text-white/40 text-xs font-body mt-0.5">
          Coming up at Deaf Puppy Comedy Club
        </p>
      </div>

      <div className="flex-1 scroll-area px-4 pb-4 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <div className="text-3xl animate-spin">🐾</div>
          </div>
        ) : events.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/20 gap-3">
            <div className="text-5xl">🎟️</div>
            <p className="font-body text-sm">No upcoming events posted yet</p>
            <p className="text-xs">Check back soon or follow us on Instagram</p>
          </div>
        ) : (
          events.map((event) => (
            <EventCard key={event.id} event={event} formatDate={formatDate} isToday={isToday} />
          ))
        )}
      </div>
    </div>
  )
}

function EventCard({ event, formatDate, isToday }) {
  const today = isToday(event.event_date)

  return (
    <div className={`rounded-2xl overflow-hidden border
      ${today ? 'border-pink/40' : 'border-white/10'}
      ${event.is_featured ? 'bg-gradient-to-br from-pink/10 to-purple/5' : 'bg-elevated'}`}>

      {today && (
        <div className="bg-pink px-4 py-1.5">
          <p className="font-display text-white text-xs tracking-widest">⚡ TONIGHT</p>
        </div>
      )}

      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <h3 className="font-display text-white text-xl tracking-wide leading-tight">
              {event.title}
            </h3>
            {event.performer && (
              <p className="text-pink text-sm font-display tracking-wide mt-0.5">
                {event.performer}
              </p>
            )}
            {event.description && (
              <p className="text-white/50 text-xs font-body mt-2 leading-relaxed">
                {event.description}
              </p>
            )}
          </div>
          <div className="flex-shrink-0 text-right">
            <p className="font-display text-sm text-white/60 tracking-wide">
              {formatDate(event.event_date)}
            </p>
            {event.start_time && (
              <p className="text-white/30 text-xs font-body mt-0.5">{event.start_time}</p>
            )}
            {event.ticket_price && (
              <p className="score-font text-cyan text-sm mt-1">
                ${parseFloat(event.ticket_price).toFixed(0)}
              </p>
            )}
          </div>
        </div>

        {event.ticket_url && (
          <a
            href={event.ticket_url}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 block w-full text-center py-2.5 rounded-xl font-display tracking-widest
              text-sm bg-pink/20 border border-pink/40 text-pink btn-press"
          >
            GET TICKETS →
          </a>
        )}
      </div>
    </div>
  )
}
