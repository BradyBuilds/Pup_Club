import { useEffect, useState } from 'react'
import { useStore } from '../store/useStore'
import { getMenu } from '../lib/supabase'

const CATEGORY_META = {
  drinks:   { icon: '🍺', label: 'Drinks',   color: 'cyan'   },
  food:     { icon: '🍔', label: 'Food',     color: 'orange' },
  specials: { icon: '⚡', label: 'Specials', color: 'yellow' },
  cocktails:{ icon: '🍹', label: 'Cocktails', color: 'pink'  },
  shots:    { icon: '🥃', label: 'Shots',    color: 'purple' },
}

export default function Menu() {
  const { venue } = useStore()
  const [items, setItems]         = useState([])
  const [loading, setLoading]     = useState(true)
  const [activeCategory, setActiveCat] = useState('specials')

  useEffect(() => {
    if (!venue) return
    getMenu(venue.id)
      .then((data) => {
        setItems(data)
        // Default to specials if any exist, else first category
        const cats = [...new Set(data.map((i) => i.category))]
        if (cats.includes('specials')) setActiveCat('specials')
        else if (cats.length > 0) setActiveCat(cats[0])
      })
      .finally(() => setLoading(false))
  }, [venue])

  const categories = [...new Set(items.map((i) => i.category))]
  const visible    = items.filter((i) => i.category === activeCategory)

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 pt-5 pb-3 flex-shrink-0">
        <h1 className="font-display text-3xl tracking-widest text-white">MENU</h1>
        <p className="text-white/40 text-xs font-body mt-0.5">
          Tonight's offerings · Ask your server
        </p>
      </div>

      {/* Category tabs */}
      <div className="px-4 flex gap-2 overflow-x-auto pb-3 flex-shrink-0">
        {categories.map((cat) => {
          const meta = CATEGORY_META[cat] || { icon: '🍽️', label: cat, color: 'pink' }
          const active = cat === activeCategory
          return (
            <button
              key={cat}
              onClick={() => setActiveCat(cat)}
              className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full
                font-display text-sm tracking-wide transition-all btn-press
                ${active
                  ? `bg-${meta.color} text-white`
                  : 'bg-elevated text-white/40 border border-white/10'}`}
              style={active ? { background: `var(--tw-gradient-from, #FF2D78)` } : {}}
            >
              <span>{meta.icon}</span>
              <span>{meta.label}</span>
            </button>
          )
        })}
      </div>

      {/* Items */}
      <div className="flex-1 scroll-area px-4 pb-4 space-y-3">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <div className="text-3xl animate-spin">🐾</div>
          </div>
        ) : visible.length === 0 ? (
          <div className="text-center text-white/20 py-12 font-body text-sm">
            Nothing here yet tonight
          </div>
        ) : (
          visible.map((item) => (
            <MenuItemCard key={item.id} item={item} />
          ))
        )}
      </div>
    </div>
  )
}

function MenuItemCard({ item }) {
  const isSpecial  = item.is_special || item.category === 'specials'
  const isFeatured = item.is_featured

  return (
    <div className={`rounded-2xl p-4 border
      ${isSpecial
        ? 'bg-yellow/5 border-yellow/30'
        : isFeatured
        ? 'bg-pink/5 border-pink/20'
        : 'bg-elevated border-white/5'}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className={`font-display text-lg tracking-wide
              ${isSpecial ? 'text-yellow' : 'text-white'}`}>
              {item.name}
            </h3>
            {isSpecial  && <span className="text-[9px] font-display tracking-wider bg-yellow/20 text-yellow px-2 py-0.5 rounded-full">SPECIAL</span>}
            {isFeatured && !isSpecial && <span className="text-[9px] font-display tracking-wider bg-pink/20 text-pink px-2 py-0.5 rounded-full">FEATURED</span>}
          </div>
          {item.description && (
            <p className="text-white/40 text-xs font-body mt-1 leading-relaxed">
              {item.description}
            </p>
          )}
          {(item.available_from || item.available_until) && (
            <p className="text-yellow/60 text-[10px] font-body mt-1">
              {item.available_from && `From ${item.available_from}`}
              {item.available_from && item.available_until && ' · '}
              {item.available_until && `Until ${item.available_until}`}
            </p>
          )}
        </div>
        {item.price && (
          <div className={`flex-shrink-0 score-font text-xl
            ${isSpecial ? 'text-yellow glow-neon' : 'text-white/80'}`}>
            ${parseFloat(item.price).toFixed(2)}
          </div>
        )}
      </div>
    </div>
  )
}
