import { useStore } from '../store/useStore'
import GameCard from '../components/GameCard'

export default function Hub() {
  const { games, leaderboard, patron, venue } = useStore()

  // Get top score for each game from today's leaderboard
  function getTopScore(gameId) {
    const rows = leaderboard.filter((r) => r.game_id === gameId)
    return rows.length > 0 ? rows[0] : null
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 pt-5 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl tracking-widest text-white">
              GAME HUB
            </h1>
            <p className="text-white/40 text-xs font-body mt-0.5">
              {venue?.name || 'Pup Club'} · Tonight's Arena
            </p>
          </div>
          {/* Live indicator */}
          <div className="flex items-center gap-2 bg-elevated rounded-full px-3 py-1.5">
            <div className="relative w-2 h-2">
              <div className="w-2 h-2 rounded-full bg-neon pulse-live" />
            </div>
            <span className="text-neon text-xs font-display tracking-wide">LIVE</span>
          </div>
        </div>

        {/* Patron XP bar */}
        {patron && (
          <div className="mt-3 bg-elevated rounded-xl p-3 flex items-center gap-3">
            <div className="text-xl">
              {patron.loyalty_tier === 'top_dog'     ? '🔥' :
               patron.loyalty_tier === 'pack_leader' ? '👑' :
               patron.loyalty_tier === 'alpha_pup'   ? '⚡' : '🐶'}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="font-display text-sm text-white tracking-wide">
                  {patron.display_name}
                </span>
                <span className="score-font text-cyan text-xs">
                  {patron.total_xp.toLocaleString()} XP
                </span>
              </div>
              <div className="h-1.5 bg-bg rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-pink to-cyan rounded-full transition-all duration-500"
                  style={{ width: `${Math.min((patron.total_xp % 500) / 5, 100)}%` }}
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Game cards */}
      <div className="flex-1 scroll-area px-4 pb-4 space-y-3">
        {games.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-white/20">
            <div className="text-4xl mb-3">🎮</div>
            <p className="font-body text-sm">No games tonight yet…</p>
          </div>
        ) : (
          games.map((game) => (
            <GameCard
              key={game.id}
              game={game}
              topScore={getTopScore(game.id)}
            />
          ))
        )}

        {/* Coming soon teaser */}
        <div className="border border-white/10 rounded-2xl p-4 opacity-40">
          <p className="font-display text-white/50 tracking-wider text-center text-sm">
            MORE GAMES COMING SOON
          </p>
        </div>
      </div>
    </div>
  )
}
