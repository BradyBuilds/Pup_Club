import { useStore } from '../store/useStore'
import { TIER_LABELS, getTierForXP } from '../lib/supabase'

const TIER_ORDER = ['pup', 'alpha_pup', 'pack_leader', 'top_dog']
const TIER_XP    = { pup: 0, alpha_pup: 500, pack_leader: 2000, top_dog: 10000 }

export default function Profile() {
  const { patron, clearPatron, leaderboard } = useStore()

  if (!patron) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4 p-6">
        <div className="text-5xl">👤</div>
        <p className="font-display text-white text-xl tracking-wide">No Profile Yet</p>
        <p className="text-white/40 text-sm font-body text-center">
          Play a game to create your profile and start earning XP
        </p>
      </div>
    )
  }

  const xp      = patron.total_xp
  const tier    = patron.loyalty_tier
  const tierIdx = TIER_ORDER.indexOf(tier)
  const nextTier = TIER_ORDER[tierIdx + 1]
  const nextXP   = nextTier ? TIER_XP[nextTier] : null
  const curXP    = TIER_XP[tier]
  const progress = nextXP
    ? Math.min(((xp - curXP) / (nextXP - curXP)) * 100, 100)
    : 100

  // Find patron's best ranks across all games
  const myBests = leaderboard
    .filter((r) => r.display_name === patron.display_name)
    .sort((a, b) => a.rank - b.rank)

  return (
    <div className="h-full flex flex-col">
      <div className="px-4 pt-5 pb-3 flex-shrink-0">
        <h1 className="font-display text-3xl tracking-widest text-white">MY PROFILE</h1>
      </div>

      <div className="flex-1 scroll-area px-4 pb-4 space-y-4">
        {/* Identity card */}
        <div className="bg-elevated rounded-2xl p-5 border border-white/10">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-pink/20 border border-pink/30
              flex items-center justify-center text-3xl">
              {tier === 'top_dog'     ? '🔥' :
               tier === 'pack_leader' ? '👑' :
               tier === 'alpha_pup'   ? '⚡' : '🐶'}
            </div>
            <div>
              <p className="font-display text-white text-2xl tracking-wide">
                {patron.display_name}
              </p>
              <p className="text-pink text-sm font-display tracking-wider mt-0.5">
                {TIER_LABELS[tier]}
              </p>
              {patron.email && (
                <p className="text-white/30 text-xs font-body mt-1">{patron.email}</p>
              )}
            </div>
          </div>
        </div>

        {/* XP progress */}
        <div className="bg-elevated rounded-2xl p-4 border border-white/10">
          <div className="flex items-center justify-between mb-3">
            <p className="font-display text-white tracking-wide">XP Progress</p>
            <p className="score-font text-cyan">{xp.toLocaleString()} XP</p>
          </div>
          <div className="h-3 bg-bg rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-pink to-cyan rounded-full transition-all duration-700"
              style={{ width: `${progress}%` }}
            />
          </div>
          {nextTier && (
            <p className="text-white/30 text-xs font-body mt-2 text-right">
              {(nextXP - xp).toLocaleString()} XP to {TIER_LABELS[nextTier]}
            </p>
          )}
          {!nextTier && (
            <p className="text-yellow text-xs font-display tracking-wider mt-2 text-center glow-neon">
              MAX TIER REACHED 🔥
            </p>
          )}
        </div>

        {/* Tonight's performance */}
        {myBests.length > 0 && (
          <div className="bg-elevated rounded-2xl p-4 border border-white/10">
            <p className="font-display text-white tracking-wide mb-3">Tonight's Ranks</p>
            <div className="space-y-2">
              {myBests.map((b) => (
                <div key={b.game_id} className="flex items-center justify-between">
                  <p className="text-white/60 text-sm font-body">{b.game_name}</p>
                  <div className="flex items-center gap-3">
                    <span className="score-font text-white/50 text-sm">
                      {b.best_score.toLocaleString()}
                    </span>
                    <span className={`score-font text-sm font-bold
                      ${b.rank === 1 ? 'text-yellow glow-neon' :
                        b.rank <= 3 ? 'text-cyan' : 'text-white/40'}`}>
                      #{b.rank}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tier guide */}
        <div className="bg-elevated rounded-2xl p-4 border border-white/10">
          <p className="font-display text-white tracking-wide mb-3">Loyalty Tiers</p>
          <div className="space-y-2">
            {TIER_ORDER.map((t) => (
              <div key={t}
                className={`flex items-center justify-between py-2 px-3 rounded-xl
                  ${t === tier ? 'bg-pink/10 border border-pink/30' : ''}`}>
                <p className={`font-display text-sm tracking-wide
                  ${t === tier ? 'text-pink' : 'text-white/40'}`}>
                  {TIER_LABELS[t]}
                </p>
                <p className="score-font text-white/30 text-xs">
                  {TIER_XP[t].toLocaleString()}+ XP
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Sign out */}
        <button
          onClick={() => {
            if (window.confirm('Reset your profile? Your score stays on the board but your local session will clear.')) {
              clearPatron()
              window.location.reload()
            }
          }}
          className="w-full py-3 text-white/20 font-body text-sm text-center btn-press"
        >
          Reset local session
        </button>
      </div>
    </div>
  )
}
