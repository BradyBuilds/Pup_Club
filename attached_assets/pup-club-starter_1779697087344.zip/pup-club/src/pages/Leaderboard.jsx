import { useState } from 'react'
import { useStore } from '../store/useStore'
import { TIER_LABELS } from '../lib/supabase'

const RANK_STYLE = {
  1: { bg: 'from-yellow-400/20 to-yellow-600/5', badge: 'rank-1', icon: '👑' },
  2: { bg: 'from-gray-400/20 to-gray-600/5',    badge: 'rank-2', icon: '🥈' },
  3: { bg: 'from-orange-700/20 to-orange-900/5', badge: 'rank-3', icon: '🥉' },
}

export default function Leaderboard() {
  const { games, leaderboard, patron } = useStore()
  const [selectedGame, setSelectedGame] = useState(null)

  // Default to first game
  const activeGameId = selectedGame || games[0]?.id

  // Filter leaderboard for selected game, top 50
  const rows = leaderboard
    .filter((r) => r.game_id === activeGameId)
    .sort((a, b) => a.rank - b.rank)
    .slice(0, 50)

  // Find patron's position
  const myRow = rows.find((r) => r.display_name === patron?.display_name)

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-4 pt-5 pb-3 flex-shrink-0">
        <h1 className="font-display text-3xl tracking-widest text-white">
          LEADERBOARD
        </h1>

        {/* Date badge */}
        <div className="flex items-center gap-2 mt-1">
          <div className="relative w-2 h-2 flex-shrink-0">
            <div className="absolute inset-0 rounded-full bg-neon animate-ping opacity-75" />
            <div className="w-2 h-2 rounded-full bg-neon" />
          </div>
          <span className="text-white/40 text-xs font-body">
            Tonight's rankings · Resets at midnight
          </span>
        </div>
      </div>

      {/* Game selector tabs */}
      <div className="px-4 flex gap-2 overflow-x-auto pb-3 flex-shrink-0 scrollbar-hide">
        {games.map((g) => (
          <button
            key={g.id}
            onClick={() => setSelectedGame(g.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-full font-display text-sm tracking-wide
              transition-all btn-press
              ${g.id === activeGameId
                ? 'bg-pink text-white box-glow-pink'
                : 'bg-elevated text-white/40 border border-white/10'
              }`}
          >
            {g.name}
          </button>
        ))}
      </div>

      {/* My rank banner */}
      {myRow && (
        <div className="mx-4 mb-3 flex-shrink-0 bg-cyan/10 border border-cyan/30 rounded-xl p-3
          flex items-center gap-3">
          <span className="score-font text-cyan text-lg">#{myRow.rank}</span>
          <div className="flex-1">
            <p className="font-display text-white text-sm">Your rank tonight</p>
            <p className="score-font text-cyan/70 text-xs">
              {myRow.best_score.toLocaleString()} pts · {myRow.plays} plays
            </p>
          </div>
          {myRow.rank > 1 && (
            <p className="text-white/30 text-xs font-body text-right">
              {(rows[0].best_score - myRow.best_score).toLocaleString()} pts<br/>
              <span className="text-pink">behind #1</span>
            </p>
          )}
        </div>
      )}

      {/* Rankings list */}
      <div className="flex-1 scroll-area px-4 pb-4 space-y-2">
        {rows.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-white/20">
            <div className="text-4xl mb-3">🏆</div>
            <p className="font-body text-sm">No scores yet tonight</p>
            <p className="text-xs mt-1">Be the first on the board!</p>
          </div>
        ) : (
          rows.map((row, i) => {
            const isMe = row.display_name === patron?.display_name
            const style = RANK_STYLE[row.rank]

            return (
              <div
                key={`${row.game_id}-${row.display_name}`}
                className={`rounded-xl p-3 flex items-center gap-3 border
                  ${isMe ? 'border-cyan/40' : 'border-white/5'}
                  ${style ? `bg-gradient-to-r ${style.bg}` : 'bg-elevated'}`}
              >
                {/* Rank */}
                <div className="w-8 flex-shrink-0 text-center">
                  {style ? (
                    <span className="text-xl">{style.icon}</span>
                  ) : (
                    <span className="score-font text-white/30 text-sm">
                      #{row.rank}
                    </span>
                  )}
                </div>

                {/* Name + tier */}
                <div className="flex-1 min-w-0">
                  <p className={`font-display text-base tracking-wide truncate
                    ${isMe ? 'text-cyan' : 'text-white'}`}>
                    {row.display_name}
                    {isMe && <span className="text-cyan/60 text-xs ml-1">(you)</span>}
                  </p>
                  <p className="text-white/30 text-[10px] font-body">
                    {TIER_LABELS[row.loyalty_tier] || '🐶 Pup'} · {row.plays} plays
                  </p>
                </div>

                {/* Score */}
                <div className="score-font text-right">
                  <p className={`text-lg font-bold
                    ${row.rank === 1 ? 'text-yellow glow-neon' :
                      row.rank <= 3 ? 'text-white' : 'text-white/60'}`}>
                    {row.best_score.toLocaleString()}
                  </p>
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
