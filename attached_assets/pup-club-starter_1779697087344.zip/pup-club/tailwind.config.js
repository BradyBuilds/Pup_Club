/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg:        '#0D0D1A',
        surface:   '#1A1A2E',
        elevated:  '#252540',
        pink:      '#FF2D78',
        cyan:      '#00E5FF',
        neon:      '#39FF14',
        yellow:    '#F5E642',
        purple:    '#7B2FBE',
        orange:    '#FF6B35',
      },
      fontFamily: {
        display: ['Barlow Condensed', 'sans-serif'],
        body:    ['DM Sans', 'sans-serif'],
        mono:    ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
