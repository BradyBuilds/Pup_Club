-- ============================================================
-- PUP CLUB — SUPABASE MIGRATION
-- Paste this entire file into: Supabase → SQL Editor → New Query → Run
-- ============================================================

-- ─── EXTENSIONS ───────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ─── 1. VENUES ────────────────────────────────────────────
create table if not exists venues (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  slug          text not null unique,
  location      text,
  timezone      text not null default 'America/Los_Angeles',
  branding      jsonb default '{}',
  features      jsonb default '{}',
  created_at    timestamptz default now()
);

-- Insert Deaf Puppy Comedy Club as the default venue
insert into venues (name, slug, location, timezone)
values ('Deaf Puppy Comedy Club', 'dpcc', 'Manteca, CA', 'America/Los_Angeles')
on conflict (slug) do nothing;

-- ─── 2. PATRONS ───────────────────────────────────────────
create table if not exists patrons (
  id              uuid primary key default uuid_generate_v4(),
  venue_id        uuid references venues(id) on delete cascade,
  display_name    text not null,
  email           text,
  phone           text,
  session_token   text unique not null,
  total_xp        integer not null default 0,
  loyalty_tier    text not null default 'pup',
  table_id        text,
  created_at      timestamptz default now(),
  last_seen_at    timestamptz default now()
);

create index if not exists patrons_venue_idx on patrons(venue_id);
create index if not exists patrons_token_idx on patrons(session_token);
create index if not exists patrons_xp_idx on patrons(total_xp desc);

-- ─── 3. GAMES ─────────────────────────────────────────────
create table if not exists games (
  id              uuid primary key default uuid_generate_v4(),
  venue_id        uuid references venues(id) on delete cascade,
  name            text not null,
  slug            text not null,
  description     text,
  max_duration    integer not null default 90,
  is_active       boolean not null default true,
  sort_order      integer not null default 0,
  config          jsonb default '{}',
  created_at      timestamptz default now(),
  unique(venue_id, slug)
);

-- Insert the 3 launch games
insert into games (venue_id, name, slug, description, max_duration, sort_order)
select 
  v.id,
  g.name,
  g.slug,
  g.description,
  g.max_duration,
  g.sort_order
from venues v
cross join (values
  ('Pong', 'pong', 'Classic paddle battle. Keep the ball alive.', 90, 1),
  ('Neon Invaders', 'neon-invaders', 'Tap the invaders before they reach you.', 60, 2),
  ('Laser Tug-of-War', 'laser-tug', 'Push the laser past your opponent.', 120, 3)
) as g(name, slug, description, max_duration, sort_order)
where v.slug = 'dpcc'
on conflict (venue_id, slug) do nothing;

-- ─── 4. SCORES ────────────────────────────────────────────
create table if not exists scores (
  id              uuid primary key default uuid_generate_v4(),
  game_id         uuid references games(id) on delete cascade,
  patron_id       uuid references patrons(id) on delete cascade,
  venue_id        uuid references venues(id) on delete cascade,
  score           integer not null default 0,
  duration_secs   integer,
  session_date    date not null default current_date,
  anti_cheat_hash text,
  created_at      timestamptz default now()
);

create index if not exists scores_game_date_idx on scores(game_id, session_date);
create index if not exists scores_patron_idx on scores(patron_id);
create index if not exists scores_venue_date_idx on scores(venue_id, session_date);

-- ─── 5. REWARDS ───────────────────────────────────────────
create table if not exists rewards (
  id              uuid primary key default uuid_generate_v4(),
  patron_id       uuid references patrons(id) on delete cascade,
  venue_id        uuid references venues(id) on delete cascade,
  type            text not null default 'score_milestone',
  title           text not null,
  description     text,
  reward_code     text unique not null default upper(substring(uuid_generate_v4()::text, 1, 8)),
  is_redeemed     boolean not null default false,
  redeemed_at     timestamptz,
  expires_at      timestamptz default (now() + interval '3 hours'),
  created_at      timestamptz default now()
);

create index if not exists rewards_patron_idx on rewards(patron_id);
create index if not exists rewards_code_idx on rewards(reward_code);

-- ─── 6. MENU ITEMS ────────────────────────────────────────
create table if not exists menu_items (
  id              uuid primary key default uuid_generate_v4(),
  venue_id        uuid references venues(id) on delete cascade,
  category        text not null default 'drinks',
  name            text not null,
  description     text,
  price           numeric(6,2),
  image_url       text,
  is_available    boolean not null default true,
  is_featured     boolean not null default false,
  is_special      boolean not null default false,
  available_from  time,
  available_until time,
  sort_order      integer not null default 0,
  created_at      timestamptz default now()
);

-- Sample menu items
insert into menu_items (venue_id, category, name, description, price, is_featured)
select v.id, m.category, m.name, m.description, m.price, m.is_featured
from venues v
cross join (values
  ('drinks', 'House Beer', 'Cold draft on tap', 5.00, false),
  ('drinks', 'Pup Club Punch', 'Our signature cocktail. Ask your server.', 9.00, true),
  ('drinks', 'Top Shelf Whiskey', 'Well-aged, smooth, and dangerous.', 12.00, false),
  ('food', 'Loaded Nachos', 'House chips, queso, jalapeños, sour cream', 12.00, true),
  ('food', 'Pretzel Bites', 'Warm soft pretzels with beer cheese dip', 8.00, false),
  ('specials', 'Happy Hour Draft', '$3 drafts 5–7PM nightly', 3.00, true)
) as m(category, name, description, price, is_featured)
where v.slug = 'dpcc'
on conflict do nothing;

-- ─── 7. EVENTS ────────────────────────────────────────────
create table if not exists events (
  id              uuid primary key default uuid_generate_v4(),
  venue_id        uuid references venues(id) on delete cascade,
  title           text not null,
  description     text,
  performer       text,
  event_date      date not null,
  start_time      time,
  end_time        time,
  ticket_url      text,
  ticket_price    numeric(6,2),
  is_featured     boolean not null default false,
  is_active       boolean not null default true,
  created_at      timestamptz default now()
);

-- ─── 8. SPONSORS ──────────────────────────────────────────
create table if not exists sponsors (
  id              uuid primary key default uuid_generate_v4(),
  venue_id        uuid references venues(id) on delete cascade,
  name            text not null,
  logo_url        text,
  link_url        text,
  tagline         text,
  placements      jsonb default '[]',
  campaign_start  date,
  campaign_end    date,
  is_active       boolean not null default true,
  created_at      timestamptz default now()
);

-- ─── 9. PUSH SUBSCRIPTIONS ────────────────────────────────
create table if not exists push_subscriptions (
  id              uuid primary key default uuid_generate_v4(),
  patron_id       uuid references patrons(id) on delete cascade,
  endpoint        text not null,
  p256dh          text not null,
  auth            text not null,
  created_at      timestamptz default now()
);

-- ─── 10. GAME SESSIONS (anti-cheat seeds) ─────────────────
create table if not exists game_sessions (
  id              uuid primary key default uuid_generate_v4(),
  patron_id       uuid references patrons(id) on delete cascade,
  game_id         uuid references games(id) on delete cascade,
  salt            text not null default uuid_generate_v4()::text,
  is_used         boolean not null default false,
  created_at      timestamptz default now(),
  expires_at      timestamptz default (now() + interval '10 minutes')
);

-- ─── ROW LEVEL SECURITY ───────────────────────────────────

alter table venues           enable row level security;
alter table patrons          enable row level security;
alter table games            enable row level security;
alter table scores           enable row level security;
alter table rewards          enable row level security;
alter table menu_items       enable row level security;
alter table events           enable row level security;
alter table sponsors         enable row level security;
alter table push_subscriptions enable row level security;
alter table game_sessions    enable row level security;

-- Public read policies (patrons can read venue data)
create policy "public read venues"      on venues      for select using (true);
create policy "public read games"       on games       for select using (is_active = true);
create policy "public read scores"      on scores      for select using (true);
create policy "public read menu"        on menu_items  for select using (is_available = true);
create policy "public read events"      on events      for select using (is_active = true);
create policy "public read sponsors"    on sponsors    for select using (is_active = true);

-- Patrons: insert own row
create policy "patrons insert self"     on patrons     for insert with check (true);
create policy "patrons read all"        on patrons     for select using (true);
create policy "patrons update self"     on patrons     for update using (true);

-- Scores: anyone can insert (anti-cheat handled in edge function)
create policy "scores insert"          on scores      for insert with check (true);

-- Rewards: insert + read
create policy "rewards insert"         on rewards     for insert with check (true);
create policy "rewards read"           on rewards     for select using (true);
create policy "rewards update"         on rewards     for update using (true);

-- Game sessions
create policy "sessions insert"        on game_sessions for insert with check (true);
create policy "sessions read"          on game_sessions for select using (true);
create policy "sessions update"        on game_sessions for update using (true);

-- Push subscriptions
create policy "push insert"            on push_subscriptions for insert with check (true);
create policy "push read self"         on push_subscriptions for select using (true);

-- ─── REALTIME ─────────────────────────────────────────────
-- Enable realtime on scores so leaderboard updates live
begin;
  drop publication if exists supabase_realtime;
  create publication supabase_realtime;
commit;

alter publication supabase_realtime add table scores;
alter publication supabase_realtime add table patrons;
alter publication supabase_realtime add table menu_items;

-- ─── HELPER VIEWS ─────────────────────────────────────────

-- Nightly leaderboard per game (today's date, top 50)
create or replace view leaderboard_today as
select
  s.game_id,
  g.name as game_name,
  g.slug as game_slug,
  p.display_name,
  p.loyalty_tier,
  max(s.score) as best_score,
  count(*) as plays,
  rank() over (partition by s.game_id order by max(s.score) desc) as rank
from scores s
join patrons p on p.id = s.patron_id
join games g on g.id = s.game_id
where s.session_date = current_date
group by s.game_id, g.name, g.slug, p.display_name, p.loyalty_tier
order by s.game_id, best_score desc;

-- All-time leaderboard per game
create or replace view leaderboard_alltime as
select
  s.game_id,
  g.name as game_name,
  g.slug as game_slug,
  p.display_name,
  p.loyalty_tier,
  max(s.score) as best_score,
  count(*) as plays,
  rank() over (partition by s.game_id order by max(s.score) desc) as rank
from scores s
join patrons p on p.id = s.patron_id
join games g on g.id = s.game_id
group by s.game_id, g.name, g.slug, p.display_name, p.loyalty_tier
order by s.game_id, best_score desc;

-- ─── DONE ─────────────────────────────────────────────────
-- Verify: select * from venues; — should return 1 row (DPCC)
-- Verify: select * from games;  — should return 3 rows
-- Verify: select * from menu_items; — should return 6 rows
