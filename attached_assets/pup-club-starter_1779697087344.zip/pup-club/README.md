# 🐾 Pup Club — Setup Guide

## Step 1: Run the Database Migration

1. Go to **https://supabase.com/dashboard/project/fsxsdrxydjvhtozpixar**
2. Click **SQL Editor** in the left sidebar
3. Click **New Query**
4. Open `supabase_migration.sql` from this project
5. Copy the entire contents and paste into the SQL Editor
6. Click **Run** (green button)
7. Verify: run `select * from venues;` — should return 1 row (DPCC)
8. Verify: run `select * from games;`  — should return 3 rows
9. Verify: run `select * from menu_items;` — should return 6 rows

## Step 2: Set Up Replit

1. Go to **https://replit.com** → New Repl → **React** template
2. Name it `pup-club`
3. Delete all default files in the src/ folder
4. Copy every file from this project into Replit, matching the folder structure exactly

## Step 3: Add Environment Variables in Replit

In Replit, click the **Secrets** tab (lock icon in left sidebar) and add:

```
VITE_SUPABASE_URL     = https://fsxsdrxydjvhtozpixar.supabase.co
VITE_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_VENUE_SLUG       = dpcc
```

> ⚠️ Do NOT use the .env file in Replit — use Secrets instead. The .env file is for local dev only.

## Step 4: Install Dependencies

In the Replit Shell tab:
```bash
npm install
```

## Step 5: Run the App

```bash
npm run dev
```

The app will open in Replit's preview panel. You should see:
- The Pup Club loading screen (🐾 + neon pink logo)
- The onboarding modal asking for your name
- After entering your name: the Game Hub with 3 game cards
- Bottom navigation (Games, Board, Menu, Events, Me)

## What Works Right Now

✅ Patron onboarding (name + optional email saved to Supabase)
✅ Game Hub UI with all 3 game cards
✅ Leaderboard page (live, updates in real-time when scores are submitted)
✅ Menu page with categories and tonight's specials
✅ Events page (add events via Supabase dashboard)
✅ Profile page with XP + tier progress
✅ Session persistence (patron remembered on return visit)

## What's Next (Sprint 2)

- [ ] Pong game engine (Canvas API)
- [ ] Score submission → leaderboard update
- [ ] Reward trigger on milestone
- [ ] Admin panel

## Folder Structure

```
pup-club/
├── supabase_migration.sql   ← Run this in Supabase first
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── index.html
├── .env                     ← Local dev only (use Replit Secrets in prod)
├── public/
│   └── manifest.json
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── index.css
    ├── lib/
    │   └── supabase.js      ← All database helpers
    ├── store/
    │   └── useStore.js      ← Global state (Zustand)
    ├── pages/
    │   ├── Hub.jsx
    │   ├── Leaderboard.jsx
    │   ├── Menu.jsx
    │   ├── Events.jsx
    │   └── Profile.jsx
    └── components/
        ├── BottomNav.jsx
        ├── GameCard.jsx
        ├── LoadingScreen.jsx
        ├── OnboardingModal.jsx
        └── RewardToast.jsx
```

## Adding Events via Supabase

Go to Supabase → Table Editor → events → Insert row:
- `venue_id`: copy from venues table
- `title`: "Friday Night Comedy Showcase"
- `performer`: "Headliner Name"
- `event_date`: "2025-06-07"
- `start_time`: "20:00:00"
- `ticket_price`: 15.00
- `is_active`: true
