-- ────────────────────────────────────────────────────────────────────────────
-- Stack Wars — Supabase migration
-- Run in: Supabase Dashboard → SQL Editor → New Query
-- ────────────────────────────────────────────────────────────────────────────

-- 1. Rooms table
create table if not exists stack_wars_rooms (
  id          uuid primary key default gen_random_uuid(),
  code        text unique not null,
  venue_id    uuid references venues(id) on delete cascade,
  host_id     text not null,
  status      text default 'waiting'
                check (status in ('waiting','countdown','playing','finished')),
  created_at  timestamptz default now()
);

-- Fast lookups by code (what players type in)
create index if not exists idx_rooms_code   on stack_wars_rooms(code);
create index if not exists idx_rooms_status on stack_wars_rooms(status);

-- 2. Real-time: enable for the rooms table (presence + broadcasts go over channels,
--    but we use DB for persistent status so spectators can see live games)
alter publication supabase_realtime add table stack_wars_rooms;

-- 3. RLS policies — players can read rooms, only the host can update them
alter table stack_wars_rooms enable row level security;

create policy "Anyone can read rooms"
  on stack_wars_rooms for select using (true);

create policy "Anyone can create a room"
  on stack_wars_rooms for insert with check (true);

create policy "Host can update their room"
  on stack_wars_rooms for update using (host_id = auth.uid()::text)
  with check (host_id = auth.uid()::text);

-- 4. Auto-cleanup: delete rooms older than 2 hours (keeps the table lean)
--    Option A — pg_cron (if enabled on your Supabase plan):
-- select cron.schedule('cleanup-stale-rooms', '*/30 * * * *', $$
--   delete from stack_wars_rooms where created_at < now() - interval '2 hours';
-- $$);

--    Option B — Supabase Edge Function (free tier):
--    Deploy a function that runs on a schedule and deletes stale rooms.
--    Paste into supabase/functions/cleanup-rooms/index.ts and add to cron.

-- 5. Game scores are already handled by the existing `scores` table.
--    Stack Wars writes: game_id = 'stack-wars', score = final score, 
--    metadata = { room_code, lines, level, placement }
--    Make sure 'stack-wars' exists in your games table:
insert into games (id, name, description, is_active)
values ('stack-wars', 'Stack Wars', 'Competitive Tetris — send garbage rows to rivals', true)
on conflict (id) do nothing;
