/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // ── Brand core ──────────────────────────────
        bg:         '#0B0A07',   // very dark warm black
        surface:    '#1A1712',   // dark warm charcoal
        elevated:   '#252218',   // slightly lighter charcoal
        border:     '#3A3220',   // subtle warm border

        // ── Gold system ─────────────────────────────
        gold:       '#C9922A',   // primary gold
        'gold-lt':  '#F0C040',   // bright highlight gold
        'gold-dk':  '#7A5C10',   // dark shadow gold
        'gold-dim': '#6B5010',   // very dark gold

        // ── Accent ──────────────────────────────────
        red:        '#CC2200',   // bow red
        'red-lt':   '#FF3B1A',   // bright red
        cream:      '#F5E0C0',   // warm cream text
        'cream-dk': '#BFA882',   // muted cream

        // ── Utility ─────────────────────────────────
        ink:        '#E8D8B8',   // primary text
        muted:      '#7A6A50',   // muted text
        chain:      '#B8922A',   // chain gold
      },
      fontFamily: {
        display: ['Anton', 'sans-serif'],          // DEAF PUPPY bold headers
        script:  ['Pacifico', 'cursive'],          // Comedy Club script
        body:    ['DM Sans', 'sans-serif'],         // readable body
        mono:    ['JetBrains Mono', 'monospace'],  // scores/numbers
      },
      backgroundImage: {
        'gold-gradient':  'linear-gradient(135deg, #F0C040, #C9922A, #7A5C10)',
        'gold-shine':     'linear-gradient(105deg, #7A5C10 0%, #F0C040 45%, #C9922A 55%, #7A5C10 100%)',
        'dark-gradient':  'linear-gradient(180deg, #252218 0%, #1A1712 100%)',
        'card-gradient':  'linear-gradient(145deg, #2A2518 0%, #1A1712 100%)',
      },
    },
  },
  plugins: [],
}
